package transaction_runner;

import java.io.*;
import java.sql.*;
import java.util.*;
import queries.Query;

public class First {

	public static int zip = 0; 
	public static int mon = 0;
	public static int yr = 0;
	
	
	
	public static void main (String[] args) throws IOException, SQLException{
		
		
		
		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
		new First().getClass().getClassLoader()
		.getResource("loginfo/LogInfo")
		.getFile()  
		); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		
//SETTING UP SCANNER FOR FIRST QUERY 
		

		 Scanner zp = new Scanner (System.in);
		 
for (int k = 0; k < 3; k++){
			 
		if (k==0){ 
		System.out.println(" ");
		System.out.print("What Zip code do you want to view? ");
		zip = zp.nextInt();
		System.out.println(" ");
		}
		if (k==1){
		System.out.print("What month? ");
		mon = zp.nextInt();
		System.out.println(" ");
		}
		if (k==2){
		System.out.print("What Year? ");
		yr = zp.nextInt();	
		System.out.println(" ");
		}
	 
}

		Connection conn = DriverManager.getConnection(url, user, password);
		Query myQueries = new Query();
		String query = myQueries.getQuery(zip, mon, yr); 
		PreparedStatement state = conn.prepareStatement(query);
		ResultSet que = state.executeQuery(query);				
		
		String[] ct= query.split(",");
		 
		
		int r = 0;
		for (r= 1; r < ct.length;r++ ){
		  }
		
//---------------------------------------------		
		
		
	 
		
while(!que.next()){
	System.out.println("There is an error in your input. Please Fix.");
	transaction_runner.First.main(args);
}


while (que.next()){

// ATTEMPT TO CALL FROM QUERY 
	

	
for (int w = 1; w <= r ; w++){
if (w == 1){
	
	String id = que.getString(w);
	System.out.println("-----------------------------------------");
	System.out.println(" ");
	System.out.print("Transaction ID :" + id);
}
		
if (w == 2){
		String dy = que.getString(w);
		System.out.println(" ");
		System.out.print("Day: " + dy);
		
}
if (w == 3){
		String mo = que.getString(w);
		System.out.println(" ");
		System.out.print("Month: " + mo);
}		
if (w == 4){
		String year = que.getString(w);
		System.out.println(" ");
		System.out.print("Year: " + year);
}
if (w == 5){
	String ccn = que.getString(w);
	System.out.println(" ");
	System.out.print("Credit Card No: " + ccn);
}
if  (w== 6){
	String ssn = que.getString(w);

	System.out.println(" ");
	System.out.print("Social Security: " + ssn);
}
if (w ==7){
	String bc = que.getString(w);
	System.out.println(" ");
	System.out.print("Branch Code: " + bc);
}
if (w == 8){
	String trans = que.getString(w);
	System.out.println(" ");
	System.out.print("Transaction Type: " + trans);
}
if (w == 9){
	double transv = que.getDouble(w);
	System.out.println(" ");
	System.out.println("Transaction Value: $" + transv);
	System.out.println("-----------------------------------------");
				}
			}	
		}

	String ans = null;
	Scanner scan = new Scanner (System.in);
	System.out.println(" ");
	System.out.println("Do you want to continue your inquiry? Y/N ");
	ans = scan.next();
	if (ans.equals("Y")|| ans.equals("y")){
		System.out.println(" ");	
		main_menu.Interface.main(args);
	}
	
	else
		System.out.println("Thank you for utilizing this service. Good Bye ");
	conn.close();	
}
	 }
