package queries;

public class Query6 {

	public String  getQuery(Long ccn, Integer mth,Integer yr){
		return "SELECT CC.DAY, CC.MONTH, CC.YEAR, "
				+ "CC.TRANSACTION_TYPE, CC.TRANSACTION_VALUE FROM CDW_SAPP_CUSTOMER C "
				+ "JOIN CDW_SAPP_CREDITCARD CC ON (C.SSN = CC.CUST_SSN) AND (C.CREDIT_CARD_NO = CC.CREDIT_CARD_NO)"
				+ " WHERE MONTH = '" + mth + "' AND YEAR = '"+ yr +"' AND CC.CREDIT_CARD_NO = " + ccn 
				+ " GROUP BY CC.TRANSACTION_ID";
	}
	
	public String  getQueryheader(Long ccn){
		return "SELECT FIRST_NAME, LAST_NAME,CREDIT_CARD_NO, APT_NO, STREET_NAME, "
				+ "CUST_CITY, CUST_STATE, CUST_ZIP FROM CDW_SAPP_CUSTOMER "
				+ " WHERE CREDIT_CARD_NO = " + ccn ;
				
	}
	
	public String getQueryin( Long ccn, Integer mth, Integer yr){
	return "SELECT SUM(TRANSACTION_VALUE) FROM"
			+ " CDW_SAPP_CREDITCARD WHERE CREDIT_CARD_NO = '" + ccn + "' and MONTH = '"+ mth + "' AND YEAR = '" + yr +"' GROUP BY CREDIT_CARD_NO";
	}
	
	
	
}
