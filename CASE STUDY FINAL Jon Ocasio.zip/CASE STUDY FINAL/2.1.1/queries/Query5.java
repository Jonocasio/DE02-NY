package queries;

public class Query5 {

	public String Queryinfo(String firstname, String lastname){
		return "select CREDIT_CARD_NO as 'Credit card', FIRST_NAME as 'First Name', LAST_NAME as 'Last Name', SSN as 'Social Security Number', concat (STREET_NAME,' ','Apt no ',APT_NO) as 'Address' , CUST_PHONE as 'Phone Number', CUST_CITY as 'City', CUST_STATE as 'State',CUST_ZIP as 'Zip',CUST_EMAIL as 'Email' , CUST_COUNTRY as 'Country' from CDW_SAPP_CUSTOMER where First_name = '" + firstname + "' AND LAST_NAME = '" + lastname +"'";
		}
	
	public String Queryssn(String firstname, String lastname){
		return "select SSN from CDW_SAPP_CUSTOMER WHERE FIRST_NAME = '"+firstname+"' and LAST_NAME = '"+ lastname+"'";
	}
	
	public String Querybefore(String colname, String firstname, String lastname){
		return "select " + colname + " from CDW_SAPP_CUSTOMER where FIRST_NAME = '" + firstname + "' AND LAST_NAME = '" + lastname+"'";
	}
	
	public String Queryafterint(String colname, String firstname, String lastname, String ins_var){
		return "UPDATE CDW_SAPP_CUSTOMER SET "+ colname + " = '" + ins_var +"' where FIRST_NAME = '"+firstname+"' and LAST_NAME = '"+lastname+"'";
	}
	
	public String Queryafterstr(String colname, String firstname, String lastname, String ins_var){
		return "UPDATE CDW_SAPP_CUSTOMER SET "+ colname + " = '" + ins_var +"' where FIRST_NAME = '"+firstname+"' and LAST_NAME = '"+lastname+"'";
	}
	public String Queinfo (String colname, String firstname,String lastname){
	return "Select "+colname+" from CDW_SAPP_CUSTOMER where FIRST_NAME = '"+ firstname + "' and LAST_NAME = '" + lastname +"'";
	}
}
