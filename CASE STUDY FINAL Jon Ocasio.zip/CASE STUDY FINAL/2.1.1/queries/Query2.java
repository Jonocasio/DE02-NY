package queries;

public class Query2 {

		
		public final static String query = "SELECT TRANSACTION_TYPE"
				+ " FROM CDW_SAPP_CREDITCARD GROUP BY TRANSACTION_TYPE";	
	
		public String  getQuery(String type)		{
				return "SELECT TRANSACTION_TYPE,"
				+ " COUNT(TRANSACTION_TYPE), SUM(TRANSACTION_VALUE) "
				+ "FROM CDW_SAPP_CREDITCARD WHERE TRANSACTION_TYPE = " + "'" + type
				+"'"+" GROUP BY TRANSACTION_TYPE";
	
}
}

