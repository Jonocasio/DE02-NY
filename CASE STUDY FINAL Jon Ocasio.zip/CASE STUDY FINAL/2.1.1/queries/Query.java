package queries;

public class Query {

	public String  getQuery(int zip ,int mon, int yr)
			{
		return "select cc.TRANSACTION_ID, cc.DAY 'Day' ,cc.MONTH ' Month' , cc.YEAR 'Year', cc.CREDIT_CARD_NO 'Credit Card No' , cc.CUST_SSN 'SSN' ,"
			+ " cc.BRANCH_CODE 'Branch Code' , cc.TRANSACTION_TYPE 'Transaction Type ' , cc.TRANSACTION_VALUE 'Transaction value'"
			+ " from CDW_SAPP_CUSTOMER c left join CDW_SAPP_CREDITCARD cc ON (c.SSN = cc.CUST_SSN) "
			+ "WHERE c.CUST_ZIP = " + zip + " && cc.MONTH = " + mon + " && cc.YEAR = " + yr + " group by TRANSACTION_ID";
		
	}
	}	