package queries;

public class Query4 {

//	public String Querynamecheck(String firstname,String lastname){
//		return "select FIRST_NAME, LAST_NAME from CDW_SAPP_CUSTOMER WHERE FIRST_NAME == '" + firstname + "' AND LAST_NAME = '" + lastname+"'" ;
//	}
	
	public String Queryinfo(String firstname, String lastname){
	return "select CREDIT_CARD_NO, FIRST_NAME, LAST_NAME, SSN, APT_NO,STREET_NAME, CUST_PHONE, CUST_CITY, CUST_STATE,CUST_ZIP,CUST_EMAIL , CUST_COUNTRY from CDW_SAPP_CUSTOMER where First_name = '" + firstname + "' AND LAST_NAME = '" + lastname +"'";
	}
	}
