package transaction_runner;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;
import queries.Query2;

public class Second {

//Global Values	
	public static int E;
	public static String type;
	
	public static void main(String[] args) throws IOException,SQLException {


		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
				new Second().getClass().getClassLoader()
				.getResource("loginfo/LogInfo")
				.getFile()  
				); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		
//SETTING UP SCANNER FOR FIRST QUERY 
				Scanner scan = new Scanner (System.in);
					
				System.out.println(" ");
				System.out.println("Which Transaction type do you want to view? ");
				
				Connection conn = DriverManager.getConnection(url, user, password);
				String query = queries.Query2.query;
				PreparedStatement state = conn.prepareStatement(query);
				ResultSet que = state.executeQuery(query);				
				
//SETTING UP LOOP FOR SELECTION
			if (!que.next()){
			System.out.println("Please input correct type.");
				}
		ArrayList<String> list = new ArrayList<String>();
			while (que.next()){
				String Trans = que.getString(1);
				list.add(Trans);
			}
		
	for (int y = 1; y <= list.size();y++){
		System.out.println(y+": " + list.get(y-1));
	}
		System.out.print("Please select a number. Your selection is : ");
			E = scan.nextInt();
		if (E > list.size()){
	System.out.println(" ");
	System.out.println("Your input does not exist. Please input a number from 1 to " + list.size());
	transaction_runner.Second.main(args);		
	}		
			System.out.println(" ");
			type = list.get(E-1);

//SETTING UP FOR SECOND QUERY			
			Query2 myQueries = new Query2();
			String query2 = myQueries.getQuery(type);
			PreparedStatement st = conn.prepareStatement(query2);
			ResultSet que2 = st.executeQuery(query2);			
			
			String[] ct= query2.split(",");
			 		
			int r = 0;
			for (r= 1; r < ct.length;r++ ){
			  }
//SECOND QUERY EXTRACTION
			while(que2.next()){
				
				for (int w = 1; w <= r ; w++){
				
				if (w==1){
					String id = que2.getString(w);
					System.out.println("-----------------------------------------");
					System.out.println(" ");
					System.out.print("Transaction Type :" + id);	
				}
				if (w==2){
					int num = que2.getInt(w);
					System.out.println(" ");
					System.out.println("Number of Transactions :" + num);
				}
				
				if (w == 3){
					double v = que2.getDouble(w);
					System.out.println("Transaction Total: " + "$" + v);
					System.out.println(" ");
					System.out.println("-----------------------------------------");
					System.out.println(" ");
					
				}
				}
			}
			String ans = null;
			System.out.println(" ");
			System.out.println("Do you want to continue your inquiry? Y/N ");
			ans = scan.next();
			if (ans.equals("Y")|| ans.equals("y")){
				System.out.println(" ");	
				main_menu.Interface.main(args);
			
			}
			
			else
				System.out.println("Thank you for utilizing this service. Good Bye ");
			conn.close();	
	
	}
}
