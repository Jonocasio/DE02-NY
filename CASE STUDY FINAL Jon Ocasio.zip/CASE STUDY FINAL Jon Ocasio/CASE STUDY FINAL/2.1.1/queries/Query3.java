package queries;

public class Query3 {

	public final static String query = "select distinct BRANCH_STATE from "
			+ "CDW_SAPP_BRANCH";

	public String  getQuery(String st)		{
		return "select count(cc.TRANSACTION_ID), sum(cc.TRANSACTION_VALUE), b.BRANCH_CITY, b.BRANCH_STATE "
				+ "from CDW_SAPP_CREDITCARD cc join CDW_SAPP_BRANCH b using (BRANCH_CODE) where b.BRANCH_STATE = "
				+ "'"+st+"'" + " group by BRANCH_CITY";
	}
}
