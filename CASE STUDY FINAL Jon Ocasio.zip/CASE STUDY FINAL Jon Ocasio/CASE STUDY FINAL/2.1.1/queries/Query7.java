package queries;

public class Query7 {

	public String Query7(String firstname, String lastname, int month1, int month2, int day1, int day2, String year1, String year2){
		return "SELECT STR_TO_DATE(concat(cc.YEAR,'-',cc.MONTH,'-',cc.DAY),'%Y-%m-%d') AS TIME, cc.TRANSACTION_TYPE,cc.TRANSACTION_VALUE" 
				+" FROM CDW_SAPP_CREDITCARD cc join CDW_SAPP_CUSTOMER c on (cc.CUST_SSN = c.SSN)" 
			    +" WHERE c.FIRST_NAME = '"+firstname+"' and c.LAST_NAME = '"+lastname+"'" 
			    +" AND STR_TO_DATE(concat(YEAR,'-',MONTH,'-', DAY),'%Y-%m-%d') BETWEEN '"+year1+"-"+month1+"-"+day1+"' AND '"+year2+"-"+month2+"-"+day2+"'" 
			    +" ORDER BY 1";
	}
	
	public String Query7a(String firstname, String lastname)
	{
		return " select FIRST_NAME, LAST_NAME FROM CDW_SAPP_CUSTOMER WHERE"
				+ " FIRST_NAME = '" + firstname + "' AND LAST_NAME = '" + lastname +"'";
		
	}
}
