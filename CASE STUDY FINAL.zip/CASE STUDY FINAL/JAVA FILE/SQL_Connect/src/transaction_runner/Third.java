package transaction_runner;

import queries.Query;
import queries.Query2;
import queries.Query3;
import java.util.*;
import java.sql.*;
import java.io.*;

public class Third {

	public static void main(String[] args) throws IOException,SQLException {
	
		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
		new First().getClass().getClassLoader()
		.getResource("loginfo/LogInfo")
		.getFile()  
		); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		
		Connection conn = DriverManager.getConnection(url, user, password);
		String query = queries.Query3.query;
		PreparedStatement state = conn.prepareStatement(query);
		ResultSet que = state.executeQuery(query);	
		
		ArrayList<String> States = new ArrayList<String>();
		
		int stat = 0;
		Scanner sel = new Scanner (System.in);
		System.out.println(" ");
		System.out.println("Which State do you want to view the total transaction from? ");
		String st = null;
		
		while (que.next()){
			States.add(que.getString(1));
			
		}
		int x = States.size()/2;
		
	
	if (States.size() % 2 == 0){
		for (int t = 1; t <= States.size()/2; t ++){
			x++;
			System.out.println( t + ": " + States.get(t-1) + "                      "
						+ x + ": " + States.get(x-1));
				}
}
	else
		for (int t = 1; t <= States.size()/2; t ++){
		System.out.println(t+ ": " + States.get(t-1) + "             " 
				+ "x" + " :" + States.get(x));
		}	
System.out.print("Your Selection numerically: ");
	stat =sel.nextInt();
	if (stat > States.size()){
		System.out.println(" ");
		System.out.println("Incorrect selection, please input the correct number");
			transaction_runner.Third.main(args);		
			
	}
	st = States.get(stat-1);
	
	Query3 myQueries = new Query3();
	String query3 = myQueries.getQuery(st);
	PreparedStatement com = conn.prepareStatement(query3);
	ResultSet que3 = com.executeQuery(query3);	
	
	String[] ct= query3.split(",");
		
	int r = 0;
	for (r= 1; r < ct.length;r++ ){
	  }
	
	while(que3.next()){
		
		for (int w = 1; w <= r ; w++){
		
		if (w==1){
			int num = que3.getInt(w);
			System.out.println("-----------------------------------------");
			System.out.println(" ");
			System.out.print("Number of Transactions: " + num);	
		}
		if (w==2){
			double val = que3.getDouble(w);
			System.out.println(" ");
			System.out.println("Transaction Value: " + "$"+ val);
		}
		
		if (w == 3){
			String city = que3.getString(w);
			System.out.println("Branch City: " + city);
			
		}
		if (w == 4){
			String fifst = que3.getString(w);
			System.out.println("State: "+ fifst);
			System.out.println(" ");
			System.out.println("-----------------------------------------");
			System.out.println(" ");
			
		}
		}	
	}
	String ans = null;
	Scanner yn = new Scanner (System.in);
	System.out.println(" ");
	System.out.println("Do you want to continue your inquiry? Y/N ");
	ans = yn.next();
	if (ans.equals("Y")|| ans.equals("y")){
		System.out.println(" ");	
		main_menu.Interface.main(args);
	}
	else
		System.out.println("Thank you for utilizing this service. Good Bye ");
	conn.close();	
	}
	}
	
