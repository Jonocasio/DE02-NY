package customer_runner;

import java.util.*;
import main_menu.Interface;
import queries.Query;
import queries.Query6;
import java.sql.*;
import java.io.*;

public class Third {

	public static void main(String[] args) throws IOException,SQLException {

		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
				new Third().getClass().getClassLoader()
				.getResource("loginfo/LogInfo")
				.getFile()  
				); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");

//Variable assignments		
		long ccn = 0;
		int mth = 0;
		int yr = 0;
		int r = 0;
		int h = 0;
		
//credit card scanner
		Scanner cred = new Scanner (System.in);
		System.out.println("Which credit card statement do you want to view? ");
		System.out.println("Please input credit card number to get started. ");
		ccn = cred.nextLong();
		System.out.println("Thank you. Please select a month. ");
		mth=cred.nextInt();
		System.out.println("Finally, please select a year. ");
		yr = cred.nextInt();

//database opening		
		Connection conn = DriverManager.getConnection(url, user, password);
		Query6 myQueries = new Query6();
		String query6 = myQueries.getQuery(ccn,mth, yr);
		PreparedStatement state = conn.prepareStatement(query6);
		ResultSet que = state.executeQuery(query6);	

//settings for extractions		
		String[] ct= query6.split(",");
		for (r= 1; r < ct.length;r++ ){
		  }
		
		Query6 myQueriesheader = new Query6();
		String header = myQueries.getQueryheader(ccn);
		PreparedStatement top = conn.prepareStatement(header);
		ResultSet head = top.executeQuery(header);		
	
		String[] hd= header.split(",");
		for (h= 1; h < hd.length;h++ ){
		  }
		while(!head.next()){
		System.out.println(" ");
		System.out.println("One or more of your inputs were incorrect. please try again");
		System.out.println(" ");
		customer_runner.Third.main(args);
			
			
	}
		while(head.next()){
			for (int w = 1; w <= h ; w++)
{
				
				if (w==1){
					String fn = head.getString(w);
					System.out.println("-----------------------------------------");
					System.out.println(" ");
					System.out.println("First Name: " + fn);	
				}
				if (w==2){
					String ln = head.getString(w);
					//System.out.println(" ");
					System.out.println("Last Name: " + ln);
				}
				
				if (w == 3){
					long ccno = head.getLong(w);
					System.out.println("Credit Card Number: " + ccno);
						}
				if (w==4){
					int apt = head.getInt(w);
					System.out.print("Address: " + apt);
				}
				if (w==5){
					String str = head.getString(w);
					System.out.println(" " + str);
				}
				
				if (w==6){
					String cty = head.getString(w);
					System.out.print("	 " + cty);
				}
				if (w ==7){
					String st = head.getString(w);
					System.out.print(", " + st);
				}
				if (w==8){
					int zip = head.getInt(w);
					System.out.println(" " + zip);
					System.out.println(" ");
				}
				}

		}	
//add credit card stuff in original query		
		while(que.next()){
				
			
			for (int w = 1; w<= r;w++){
			if (w==1){
				int dy = que.getInt(w);
				System.out.print(dy);
			}
			if (w==2){
				int mos = que.getInt(w);
				System.out.print("/" + mos);
			}
			if (w==3){ 
			int yer = que.getInt(w);
			System.out.print("/" + yer);
			}
			if (w == 4){
				String trans_o = que.getString(w);
				System.out.print(" "+ trans_o);
			}
			if (w == 5){
				double trans_v = que.getDouble(w);
				System.out.print(" " + "$"+trans_v);
				System.out.println(" ");
			}
			}	
		}
			Query6 myQueriesin = new Query6();
			String queryin = myQueries.getQueryin(ccn, mth, yr);
			PreparedStatement states = conn.prepareStatement(queryin);
			ResultSet que1 = states.executeQuery(queryin);	
			
			while (que1.next()){
				System.out.println(" ");
				double val = que1.getDouble(1);
				System.out.println("	 Total:	    "+"$" + val);
					System.out.println(" ");
					System.out.println("-----------------------------------------");
					System.out.println(" ");		
			}
				
				
				
			
			String ans = null;
		Scanner yn = new Scanner (System.in);
		System.out.println(" ");
		System.out.println("Do you want to continue your inquiry? Y/N ");
		ans = yn.next();
		if (ans.equals("Y")|| ans.equals("y")){
			System.out.println(" ");	
			main_menu.Interface.main(args);
		
		}
		
		else
			System.out.println("Thank you for utilizing this service. Good Bye ");
		conn.close();	
	
	}
}

