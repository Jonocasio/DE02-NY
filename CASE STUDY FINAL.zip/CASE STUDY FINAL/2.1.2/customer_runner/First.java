package customer_runner;

	import java.util.*;
	import java.sql.*;
	import java.io.*;
	import queries.Query4;
import main_menu.Interface;

	public class First {

		public static void main(String[] args) throws IOException, SQLException {
			
			Properties prop = new Properties ();
			FileInputStream fis = new FileInputStream(
					new First().getClass().getClassLoader()
					.getResource("loginfo/LogInfo")
					.getFile()  
					); 
			prop.load(fis);
			
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String password = prop.getProperty("password");

			String namesplit [] = null;
			String name = null;
			String firstname = null;
			String lastname = null;
			int r = 0;
			int o = 0;
			
			System.out.println("To view customer's information, please insert customer's first and last name. ");
			Scanner scan = new Scanner (System.in);
			System.out.print("Customer Name: ");
			name = scan.nextLine();
			
			namesplit = name.split(" ");

			if (namesplit.length != 2){
			
			System.out.println("Please input the correct name");
			
			customer_runner.First.main(args);
			}
			else {
				firstname = namesplit[0];
				lastname = namesplit[1];	
			
			
			Connection conn = DriverManager.getConnection(url, user, password);
			
			Query4 fetchquery = new Query4();
			String  query_fetch =  fetchquery.Queryinfo(firstname, lastname);
			PreparedStatement ftch = conn.prepareStatement(query_fetch);
			ResultSet que_fetch = ftch.executeQuery(query_fetch);
		
			String[] ct= query_fetch.split(",");
			
			System.out.println("---------------------------");
		
			while(que_fetch.next()){
	
			for (r = 1;r <= ct.length;r++){
			
			if (r==1){
					long cc = que_fetch.getLong(r);
					System.out.println("   Credit Card No: " + cc );	
				}
				
			if (r==2){
			System.out.println(" ");
			String fn = que_fetch.getString(r);
			System.out.print("Name:	 " + fn);
			}
			if (r==3){
				String ln = que_fetch.getString(r);
				System.out.print(" "  + ln);
			}
			if (r == 4){
			long ssn = que_fetch.getLong(r);
			System.out.println("	 	  "+"SSN: " + ssn);
				
			}
			
			if (r==5){
				String apt = que_fetch.getString(r);
				System.out.print("Address :" + apt);
			}
			if (r==6){
				String str = que_fetch.getString(r);
				System.out.print(" " +str);
			}
			
			if (r==7){
				long phone = que_fetch.getLong(r);
				System.out.println("    " + "Telephone Number: " + phone);
			}
		
			if (r==8){
				String city = que_fetch.getString(r);
				System.out.print("	 "+city);
			}
			if (r==9){
				String st = que_fetch.getString(r);
				System.out.print("," + " " + st);
			}
			if (r==10){
				int zipcode = que_fetch.getInt(r);
				System.out.print(" " + zipcode);
				
			}
			if (r==11){
				String email = que_fetch.getString(r);
				System.out.println("        Email Address: " + email);
			
			}
			
			
			if (r==12){
				String ctry = que_fetch.getString(r);
				System.out.println("	 " + ctry);
				System.out.println("---------------------------");
			}		
			}	
			}
			if (!que_fetch.first()){
				System.out.println("There is no person by the name of " + firstname + " " + lastname + " in the system");
				customer_runner.First.main(args);
			}
			System.out.println(" ");
			System.out.println("Do you want to continue your inquiry? Y/N ");
			 String ans = scan.next();
			if (ans.equals("Y")|| ans.equals("y")){
				System.out.println(" ");	
				main_menu.Interface.main(args);
			}
			
			else
				System.out.println("Thank you for utilizing this service. Good Bye ");
			conn.close();	
		}
	}
		}