package customer_runner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;
import com.mysql.jdbc.ResultSetMetaData;
import queries.Query5;

public class Second {

	public static void main(String[] args) throws IOException, SQLException{
		
		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
				new Fourth().getClass().getClassLoader()
				.getResource("loginfo/LogInfo")
				.getFile()  
				); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		Connection conn = DriverManager.getConnection(url, user, password);
		
		String namesplit [] = null;
		String name = null;
		String firstname = null;
		String lastname = null;
		String colname = null;
		String ins_var = null;
		int r = 0;
		int o = 0;
		int num = 0;
		long ins_int = 0;
		System.out.println("To view customer's information, please insert customer's first and last name. ");
		Scanner scan = new Scanner (System.in);
		System.out.print("Customer Name: ");
		name = scan.nextLine();
		
		namesplit = name.split(" ");

		if (namesplit.length != 2){
		
		System.out.println("Please input the correct name");
		customer_runner.Second.main(args);
		}
		else {
			firstname = namesplit[0];
			lastname = namesplit[1];	
			
		Query5 fetchquery = new Query5();
		String  query_fetch =  fetchquery.Queryinfo(firstname, lastname);
		PreparedStatement ftch = conn.prepareStatement(query_fetch);
		ResultSet que_fetch = ftch.executeQuery(query_fetch);

		ResultSetMetaData col = (ResultSetMetaData) que_fetch.getMetaData();
		
		String[] ct= query_fetch.split(",");
		
		
		System.out.println(" ");
		
		for (r=1; r<= 11;r++){
						
			System.out.println(r+": "+ col.getColumnLabel(r));
		}
		
		System.out.println("Which category do you want to edit? ");
		num = scan.nextInt();
		colname = col.getColumnName(num);
	
		if (colname.equals("Address")){
			colname = "concat (APT_NO,' ',STREET_NAME)";
		}
	
		
		
	Query5 bforequery = new Query5();
	String  query_before = bforequery.Querybefore(colname, firstname, lastname);
	PreparedStatement bfore = conn.prepareStatement(query_before);
	ResultSet que_before = bfore.executeQuery(query_before);
	
	while(que_before.next()){
		for (r = 1;r <= 1;r++){
		if (r==1){
				String fn= que_before.getString(r);
				System.out.println( col.getColumnLabel(num) + ": " +  fn );	
			}
		}
	}
		
	System.out.println("Please input the new information. ");
	
	scan.nextLine();
	ins_var = scan.nextLine();
	
		Query5 afterquery = new Query5();
		String  query_af =  afterquery.Queryafterstr(colname, firstname, lastname, ins_var);
		PreparedStatement aft = conn.prepareStatement(query_af);
			
		aft.executeUpdate();
	
		if (num == 2){
			firstname  = ins_var;
		}
		if (num == 3){
			lastname = ins_var;
		}
	
		Query5 queryaft = new Query5();
		String  query_aft =  queryaft.Queinfo(colname,firstname, lastname);
		PreparedStatement af = conn.prepareStatement(query_aft);
		ResultSet que_aft = af.executeQuery(query_aft);	
		
		System.out.println(" ");
		while(que_aft.next()){
			for (r = 1;r <= 1;r++){
			if (r==1){
					String d = que_aft.getString(r);
					System.out.println(d + " has now been inserted in the field of " + col.getColumnLabel(num) );	
				}
			}
		}
		String ans = null;
		System.out.println(" ");
		System.out.println("Do you want to continue your inquiry? Y/N ");
		ans = scan.next();
		if (ans.equals("Y")|| ans.equals("y")){
			System.out.println(" ");	
			main_menu.Interface.main(args);
		
		}
		
		else
			System.out.println("Thank you for utilizing this service. Good Bye ");
		conn.close();	
	
	}	
		 
		 
		 
					}
	}