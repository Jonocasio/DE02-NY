package customer_runner;

import java.util.*;
import java.sql.*;
import java.io.*;
import java.lang.reflect.Array;

import queries.Query7;
import main_menu.Interface;



public class Fourth {

	public static void main(String[] args) throws IOException, SQLException {
		
		Properties prop = new Properties ();
		FileInputStream fis = new FileInputStream(
				new Fourth().getClass().getClassLoader()
				.getResource("loginfo/LogInfo")
				.getFile()  
				); 
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");

// Variables
	String name = null;
	String date1 = null;
	String date2 = null;
	String [] date_1;
	String [] date_2;
	Scanner scan = new Scanner (System.in);
	String [] nombre = null;	

		System.out.println(" ");
		System.out.print("Customer Name: ");
		name = scan.nextLine();
		nombre = name.split(" ");
		
		System.out.println(" ");
		System.out.println("To view a timespan, please insert Start date and then end date");
		System.out.println("Please insert date: MM-DD-YYYY");
		System.out.print("From: " );
		 date1 = scan.nextLine();
		date_1 = date1.split("-");
		
		
		System.out.println(" ");
		System.out.print("to: ");
		 date2 = scan.nextLine();
		date_2 = date2.split("-");
		
		
		String firstname = nombre[0];
		String lastname = nombre [1];
		
		int month1 = Integer.parseInt(date_1[0]); 
		int day1 = Integer.parseInt(date_1[1]);
		String year1 = date_1[2];
//		
		int month2 = Integer.parseInt(date_2[0]);
		int day2 = Integer.parseInt(date_2[1]);
		String year2 = date_2[2];	
			
		Connection conn = DriverManager.getConnection(url, user, password);
		
		Query7 namequery = new Query7();
		String  query_name = namequery.Query7a(firstname, lastname);
		PreparedStatement nme = conn.prepareStatement(query_name);
		ResultSet que_name = nme.executeQuery(query_name);
		
		String[] ct= query_name.split(",");
		int r = 0;
		for (r= 1; r < ct.length;r++ ){
		}
		System.out.println("");
		System.out.println("-----------------------------------------");
		while (que_name.next()){
			for (int i = 1; i <= r; i++){
				String fln = que_name.getString(i);
				System.out.print(fln + " ");
				
			}
		}
		System.out.println(" ");
		
		Query7 mainquery = new Query7();
		String query_main = mainquery.Query7(firstname, lastname, month1, month2, day1, day2, year1, year2);
		PreparedStatement state = conn.prepareStatement(query_main);
		ResultSet que = state.executeQuery(query_main);				
		
		String[] c= query_main.split(",");
		
		for (r= 1; r < c.length;r++ ){
		}
		
		while(que.next()){
			
			for (int w = 1; w <= r ; w++){
			
			if (w==1){
			
				String date = que.getString(w);
				System.out.println(" ");
				System.out.print(date);
				
			}	
			if (w == 2){
			
				String ttype = que.getString(w);
				System.out.print(" Transaction Type: " + ttype + "        ");
				
			}
			if (w == 3){
				double v = que.getDouble(w);
				System.out.print("Transaction Total: " + "$" + v);					
			}
			}
	
		}
		System.out.println(" ");
		System.out.println("-----------------------------------------");
		System.out.println(" ");

		
		String ans = null;
		System.out.println(" ");
		System.out.println("Do you want to continue your inquiry? Y/N ");
		ans = scan.next();
		if (ans.equals("Y")|| ans.equals("y")){
			System.out.println(" ");	
			main_menu.Interface.main(args);
		
		}
		
		else
			System.out.println("Thank you for utilizing this service. Good Bye ");
		conn.close();	

	}
}
