package main_menu;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import transaction_runner.First;


public class Interface {

public static Scanner scan = new Scanner (System.in);	
public static int o = 0;	
	
public static void main (String[] args) throws IOException, SQLException{
	
		ArrayList<String> quest = new ArrayList<String>();
		
		quest.add("1. Transaction information by ZIP CODE, MONTH,and YEAR.");
		quest.add("2. Transaction information by TRANSACTION TYPE.");
		quest.add("3. Transaction information by BRANCH.");
		quest.add("4. CUSTOMER ACCOUNT information. ");		
		quest.add("5. MODIFY CUSTOMER ACCOUNT information");
		quest.add("6. MONTHLY CREDIT CARD statement by MONTH AND YEAR. ");
		quest.add("7. TRANSACTIONS made by CUSTOMER between DATES. ");
		
		
		//Scanner scan = new Scanner (System.in);
		System.out.println("Welcome. Please select one");
		System.out.println(" ");
		
// LOOP FOR QUESTION OUTPUT
		for (int i = 0; i < quest.size(); i++){
			System.out.println(quest.get(i));
		}
	System.out.println(" ");
	System.out.print("Your selection: ");
		o = scan.nextInt();

//Direct user to desired option
		
if (o == 1){
//		//START IT
		transaction_runner.First.main(args);
	
}
if (o == 2){
//		//START IT
	transaction_runner.Second.main(args);
}	
if (o == 3){
	//START IT
transaction_runner.Third.main(args);
}
//
if (o == 4){
//	//START IT
	customer_runner.First.main(args);
}
//
if (o == 5){
//	//START IT
	customer_runner.Second.main(args);
}
//);
if (o == 6){
//	//START IT
	customer_runner.Third.main(args);
}
//
if (o == 7){
//	//START IT
	customer_runner.Fourth.main(args);
}
	}
}